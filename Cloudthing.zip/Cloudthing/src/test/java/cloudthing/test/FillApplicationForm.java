package cloudthing.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import cloudthing.pages.CloudthingNavigation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class FillApplicationForm {
	
	
	public static WebDriver driver;
	
	@Parameters({"cloudthing_url"})
	@Test
	public void fillFrormAndSubmit(String urlname) {
		
		System.out.println("!!!!!!!! Executing Test Suite in chrome for Success case !!!!!!!!!!");	 
		System.setProperty("webdriver.chrome.driver","C:/Users/Ashwin/eclipse-workspace/Zest/src/main/resources/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.get(urlname);
	   	
	    //Navigation to career page
		CloudthingNavigation cloudthing_nav_page = PageFactory.initElements(driver,CloudthingNavigation.class);
		cloudthing_nav_page.right_menu_button.click();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		cloudthing_nav_page.career_page.click();		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Scrolling down to view search box
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		js.executeScript("window.scrollBy(0,500)");
		
		//Search Manager job on search box
		
		cloudthing_nav_page.search_text_box.sendKeys("Manager");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		cloudthing_nav_page.arrow_nav_form.click();
		
		//Scrolling down to view form
				
		js.executeScript("window.scrollBy(0,2200)");
		
		//Entering application details
		
		cloudthing_nav_page.name_field.sendKeys ("Arpita");
		cloudthing_nav_page.email_field.sendKeys("test123@gmail.com");
		cloudthing_nav_page.anything_you_like_field.sendKeys("Test");
		cloudthing_nav_page.resume_field.sendKeys("C:\\Users\\Ashwin\\Downloads\\Automation QA Task - October 2019 (2)");
		cloudthing_nav_page.submit.click();
		

		
	
	
		
	}

	
	}


