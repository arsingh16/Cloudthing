package cloudthing.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CloudthingNavigation {
	

	public WebDriver driver = null;
	
	public CloudthingNavigation(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		}

    @FindBy(xpath="//*[@id=\'gatsby-focus-wrapper\']/div[1]/div[1]/div/img")
    public WebElement right_menu_button;
    
    @FindBy(xpath="//*[@id=\"gatsby-focus-wrapper\"]/div[1]/div[2]/div[2]/div/div[1]/div[10]/a")
    public WebElement career_page;
    
    @FindBy(xpath="//*[@id=\"gatsby-focus-wrapper\"]/div[3]/div/div/div/div[1]/div[1]/div[2]/input")
    public WebElement search_text_box;
   
    @FindBy(xpath="//*[@id=\"gatsby-focus-wrapper\"]/div[3]/div/div/div/div[2]/div[5]/a/div/img")
    public WebElement arrow_nav_form;
    
    @FindBy(id="name")
    public WebElement name_field;
    
    @FindBy(id="emailaddress")
    public WebElement email_field;
    
    @FindBy(id="anythingyoudliketotellus")
    public WebElement anything_you_like_field;
    
    @FindBy(id="resume")
    public WebElement resume_field;
    
    @FindBy(xpath="//*[@id=\"ctform\"]/button")
    public WebElement submit;
    
  
	
	}

